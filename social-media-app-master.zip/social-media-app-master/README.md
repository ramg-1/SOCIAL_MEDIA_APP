## About


It is a social media app. Front end is created using  ReactJS  providing an interactive UI for posting , liking and commenting and Backend is created using Node and ExpressJS to handle API 
request efficiently and multiple user interaction


## Run the program


Open Vscode

Open the Terminal:

Terminal - 1 :

(i) Install the packages

               npm i

Terminal - 2 :

(i) Change directory to Frontend/Client to run frontend

               cd frontend/Client
               

(ii) Run the frontend

               npm start


Terminal - 3 :

(i) Change directory to Backend to run backend

               cd Backend/Client
               

(ii) Run the Backend

               npm start


After following these procedures , 

You can visit the app on 

http://localhost:3000/


               
